public class MultiplicacionFactory extends OperacionFactory {

    @Override
    public Operacion crearOperacion() {
        return new Multiplicacion();
    }
}
