public class SalidaConsola implements Salida {

    @Override
    public void escribir(String mensaje) {
        System.out.println(mensaje);
    }
}
