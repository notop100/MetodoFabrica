public class Resta implements Operacion {

    @Override
    public int ejecutar(int a, int b) {
        return a - b;
    }
}
