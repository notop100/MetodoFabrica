public class RestaFactory extends OperacionFactory {

    @Override
    public Operacion crearOperacion() {
        return new Resta();
    }
}
