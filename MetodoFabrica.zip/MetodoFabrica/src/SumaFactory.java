public class SumaFactory extends OperacionFactory {

    @Override
    public Operacion crearOperacion() {
        return new Suma();
    }
}
