public interface Operacion {
    int ejecutar(int a, int b);
}
