public abstract class OperacionFactory {

    public abstract Operacion crearOperacion();

}
