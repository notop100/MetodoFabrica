public class Main {

    public static void main(String[] args) {

        Entrada entrada = new EntradaConsola();
        Salida salida = new SalidaConsola();

        salida.escribir("Seleccione operación:");
        salida.escribir("1. Suma");
        salida.escribir("2. Resta");
        salida.escribir("3. Multiplicación");

        String opcion = entrada.leer();

        OperacionFactory factory;

        switch (opcion) {
            case "1":
                factory = new SumaFactory();
                break;
            case "2":
                factory = new RestaFactory();
                break;
            case "3":
                factory = new MultiplicacionFactory();
                break;
            default:
                factory = new SumaFactory();
        }

        Cliente cliente = new Cliente(entrada, salida);
        cliente.ejecutar(factory);
    }
}
