public interface Salida {
    void escribir(String mensaje);
}
