public class Cliente {

    private Entrada entrada;
    private Salida salida;

    public Cliente(Entrada entrada, Salida salida) {
        this.entrada = entrada;
        this.salida = salida;
    }

    public void ejecutar(OperacionFactory factory) {

        salida.escribir("Ingrese primer número:");
        int a = Integer.parseInt(entrada.leer());

        salida.escribir("Ingrese segundo número:");
        int b = Integer.parseInt(entrada.leer());

        Operacion operacion = factory.crearOperacion();

        int resultado = operacion.ejecutar(a, b);

        salida.escribir("Resultado: " + resultado);
    }
}
