public interface Entrada {
    String leer();
}
