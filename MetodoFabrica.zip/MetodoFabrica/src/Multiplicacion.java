public class Multiplicacion implements Operacion {

    @Override
    public int ejecutar(int a, int b) {

        Suma suma = new Suma();
        int resultado = 0;

        for (int i = 0; i < b; i++) {
            resultado = suma.ejecutar(resultado, a);
        }

        return resultado;
    }
}
