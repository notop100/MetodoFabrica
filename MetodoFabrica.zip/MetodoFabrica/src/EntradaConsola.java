import java.util.Scanner;

public class EntradaConsola implements Entrada {

    private Scanner scanner = new Scanner(System.in);

    @Override
    public String leer() {
        return scanner.nextLine();
    }
}
